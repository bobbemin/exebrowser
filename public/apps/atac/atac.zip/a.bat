@echo off
intro -x %1 %2 %3 %4 %5 %6 %7 %8 %9
game %1 %2 %3 %4 %5 %6 %7 %8 %9
nc