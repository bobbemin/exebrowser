@echo off
dosbox -conf dosbox1.conf