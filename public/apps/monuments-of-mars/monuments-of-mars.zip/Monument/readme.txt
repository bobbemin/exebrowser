Monuments of Mars Freeware Release Notes - March 2009
Monuments of Mars is (c)1990/2009 Apogee Software, Ltd.
------------------------------------------------------

This game was deleted from Apogee's product line quite some time ago, and has been re-released as freeware in March of 2009.  This was the second game released by Todd Replogle through Apogee.  His first game was called "Caves of Thor", and was released a year or so before this one.  After Mars, he went on to do some more well known games like Cosmo's Cosmic Adventure and of course the first three Duke Nukem games.  This is another game that we have no idea what the exact release date is, that information has been lost to time.  Our earliest archival notes say "Unknown 1990".

1) We offer no support in helping to getting this freeware release running.  YOU'RE ON YOUR OWN HERE.  DON'T ASK US - YOU WILL BE IGNORED. :)

2) This game was released before Windows 2000 & Windows XP (or Vista, or even Windows 95) were released, and as such, these more modern operating systems might have issues in running the game.  A third party program called DOSBox has been known to have been helpful in getting the game running.  You can obtain DOSBox here: http://www.dosbox.com

3) This game is released as freeware.  That's not to be confused with public domain, abandonware (which is illegal), or releasing something under the GPL.   This is a freeware release, which means we retain full legal rights to the title and it's materials.  You are free to play the game as we've released it, but not free to "do whatever you want with it", which includes selling it or otherwise using the materials in other projects.

Traditionally, in the past, when we have released freeware, we've gotten the original developer to say a few words about the release.  That's not going to happen with this one, as Todd Replogle has lost contact with us for many a year now.  Don't have any idea how to get a hold of him to comment on this one.  :)

Enjoy Monuments of Mars!
-- Apogee Software Ltd. Tech Support, March 2009
